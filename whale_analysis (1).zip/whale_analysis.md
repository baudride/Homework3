 #  A Whale off the Port(folio)

 In this assignment, you'll get to use what you've learned this week to evaluate the performance among various algorithmic, hedge, and mutual fund portfolios and compare them against the S&P 500.


```python
import pandas as pd
import numpy as np
import datetime as dt
from pathlib import Path
%matplotlib inline
```

# Data Cleaning

In this section, you will need to read the CSV files into DataFrames and perform any necessary data cleaning steps. After cleaning, combine all DataFrames into a single DataFrame.

Files:
1. whale_returns.csv
2. algo_returns.csv
3. sp500_history.csv

## Whale Returns

Read the Whale Portfolio daily returns and clean the data


```python
# Reading whale returns
whale_returns_path = Path ("Resources/whale_returns.csv")
whale_returns = pd.read_csv(whale_returns_path, index_col = "Date",parse_dates = True, infer_datetime_format=True)
whale_returns = whale_returns.sort_index()
whale_returns.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-03-02</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2015-03-03</th>
      <td>-0.001266</td>
      <td>-0.004981</td>
      <td>-0.000496</td>
      <td>-0.006569</td>
    </tr>
    <tr>
      <th>2015-03-04</th>
      <td>0.002230</td>
      <td>0.003241</td>
      <td>-0.002534</td>
      <td>0.004213</td>
    </tr>
    <tr>
      <th>2015-03-05</th>
      <td>0.004016</td>
      <td>0.004076</td>
      <td>0.002355</td>
      <td>0.006726</td>
    </tr>
    <tr>
      <th>2015-03-06</th>
      <td>-0.007905</td>
      <td>-0.003574</td>
      <td>-0.008481</td>
      <td>-0.013098</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Count nulls
whale_returns.isnull().sum()
```




    SOROS FUND MANAGEMENT LLC      1
    PAULSON & CO.INC.              1
    TIGER GLOBAL MANAGEMENT LLC    1
    BERKSHIRE HATHAWAY INC         1
    dtype: int64




```python
# Drop nulls
whale_returns = whale_returns.dropna()
whale_returns.isnull().sum()
```




    SOROS FUND MANAGEMENT LLC      0
    PAULSON & CO.INC.              0
    TIGER GLOBAL MANAGEMENT LLC    0
    BERKSHIRE HATHAWAY INC         0
    dtype: int64




```python
whale_returns.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-03-03</th>
      <td>-0.001266</td>
      <td>-0.004981</td>
      <td>-0.000496</td>
      <td>-0.006569</td>
    </tr>
    <tr>
      <th>2015-03-04</th>
      <td>0.002230</td>
      <td>0.003241</td>
      <td>-0.002534</td>
      <td>0.004213</td>
    </tr>
    <tr>
      <th>2015-03-05</th>
      <td>0.004016</td>
      <td>0.004076</td>
      <td>0.002355</td>
      <td>0.006726</td>
    </tr>
    <tr>
      <th>2015-03-06</th>
      <td>-0.007905</td>
      <td>-0.003574</td>
      <td>-0.008481</td>
      <td>-0.013098</td>
    </tr>
    <tr>
      <th>2015-03-09</th>
      <td>0.000582</td>
      <td>0.004225</td>
      <td>0.005843</td>
      <td>-0.001652</td>
    </tr>
  </tbody>
</table>
</div>



## Algorithmic Daily Returns

Read the algorithmic daily returns and clean the data


```python
# Reading algorithmic returns
algo_returns_path = Path("Resources/algo_returns.csv")
algo_returns = pd.read_csv(algo_returns_path, index_col= "Date", parse_dates = True, infer_datetime_format=True)
algo_returns = algo_returns.sort_index()
algo_returns.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Algo 1</th>
      <th>Algo 2</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2014-05-28</th>
      <td>0.001745</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2014-05-29</th>
      <td>0.003978</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2014-05-30</th>
      <td>0.004464</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2014-06-02</th>
      <td>0.005692</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2014-06-03</th>
      <td>0.005292</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Count null
algo_returns.isnull().sum()
```




    Algo 1    0
    Algo 2    6
    dtype: int64




```python
# Drop nulls
algo_returns=algo_returns.dropna()
algo_returns.isnull().sum()
```




    Algo 1    0
    Algo 2    0
    dtype: int64




```python
algo_returns.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Algo 1</th>
      <th>Algo 2</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2014-06-05</th>
      <td>0.004062</td>
      <td>0.013285</td>
    </tr>
    <tr>
      <th>2014-06-06</th>
      <td>0.001857</td>
      <td>0.008284</td>
    </tr>
    <tr>
      <th>2014-06-09</th>
      <td>-0.005012</td>
      <td>0.005668</td>
    </tr>
    <tr>
      <th>2014-06-10</th>
      <td>0.004406</td>
      <td>-0.000735</td>
    </tr>
    <tr>
      <th>2014-06-11</th>
      <td>0.004760</td>
      <td>-0.003761</td>
    </tr>
  </tbody>
</table>
</div>



## S&P 500 Returns

Read the S&P500 Historic Closing Prices and create a new daily returns DataFrame from the data. 


```python
# Reading S&P 500 Closing Prices
sp500_history_path = Path("Resources/sp500_history.csv")
sp500_history = pd.read_csv(sp500_history_path, index_col= "Date",parse_dates = True, infer_datetime_format=True)
sp500_history = sp500_history.sort_index()
sp500_history.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-01</th>
      <td>$1444.49</td>
    </tr>
    <tr>
      <th>2012-10-02</th>
      <td>$1445.75</td>
    </tr>
    <tr>
      <th>2012-10-03</th>
      <td>$1450.99</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>$1461.40</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>$1460.93</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Check Data Types
sp500_history.dtypes
```




    Close    object
    dtype: object




```python
# Clean identified numeric fields with $ symbol
sp500_history["Close"] = sp500_history["Close"].str.replace("$", "")
sp500_history["Close"]
sp500_history.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-01</th>
      <td>1444.49</td>
    </tr>
    <tr>
      <th>2012-10-02</th>
      <td>1445.75</td>
    </tr>
    <tr>
      <th>2012-10-03</th>
      <td>1450.99</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>1461.40</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>1460.93</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Fix Data Types
sp500_history["Close"] = sp500_history["Close"].astype("float")
sp500_history.dtypes
```




    Close    float64
    dtype: object




```python
# Calculate Daily Returns
dayly_returns_sp500 = sp500_history.pct_change()
dayly_returns_sp500.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-01</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-10-02</th>
      <td>0.000872</td>
    </tr>
    <tr>
      <th>2012-10-03</th>
      <td>0.003624</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>0.007174</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>-0.000322</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Drop nulls
dayly_returns_sp500 =dayly_returns_sp500.dropna()
dayly_returns_sp500.isnull().sum()
```




    Close    0
    dtype: int64




```python
# Rename Column
dayly_returns_sp500  = dayly_returns_sp500.rename(columns= {
    "Close":"S&P 500"
})
```


```python
dayly_returns_sp500.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>S&amp;P 500</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-02</th>
      <td>0.000872</td>
    </tr>
    <tr>
      <th>2012-10-03</th>
      <td>0.003624</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>0.007174</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>-0.000322</td>
    </tr>
    <tr>
      <th>2012-10-08</th>
      <td>-0.003457</td>
    </tr>
  </tbody>
</table>
</div>



## Combine Whale, Algorithmic, and S&P 500 Returns


```python
# Concatenate all DataFrames into a single DataFrame
daylyret_all_rows = pd.concat(
    [whale_returns, algo_returns, dayly_returns_sp500], axis="columns", join="inner")
daylyret_all_rows
daylyret_all_rows.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
      <th>Algo 1</th>
      <th>Algo 2</th>
      <th>S&amp;P 500</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-03-03</th>
      <td>-0.001266</td>
      <td>-0.004981</td>
      <td>-0.000496</td>
      <td>-0.006569</td>
      <td>-0.001942</td>
      <td>-0.000949</td>
      <td>-0.004539</td>
    </tr>
    <tr>
      <th>2015-03-04</th>
      <td>0.002230</td>
      <td>0.003241</td>
      <td>-0.002534</td>
      <td>0.004213</td>
      <td>-0.008589</td>
      <td>0.002416</td>
      <td>-0.004389</td>
    </tr>
    <tr>
      <th>2015-03-05</th>
      <td>0.004016</td>
      <td>0.004076</td>
      <td>0.002355</td>
      <td>0.006726</td>
      <td>-0.000955</td>
      <td>0.004323</td>
      <td>0.001196</td>
    </tr>
    <tr>
      <th>2015-03-06</th>
      <td>-0.007905</td>
      <td>-0.003574</td>
      <td>-0.008481</td>
      <td>-0.013098</td>
      <td>-0.004957</td>
      <td>-0.011460</td>
      <td>-0.014174</td>
    </tr>
    <tr>
      <th>2015-03-09</th>
      <td>0.000582</td>
      <td>0.004225</td>
      <td>0.005843</td>
      <td>-0.001652</td>
      <td>-0.005447</td>
      <td>0.001303</td>
      <td>0.003944</td>
    </tr>
  </tbody>
</table>
</div>



---

# Portfolio Analysis

In this section, you will calculate and visualize performance and risk metrics for the portfolios.

## Performance

Calculate and Plot the daily returns and cumulative returns. Does any portfolio outperform the S&P 500? 


```python
# Plot daily returns
daylyret_all_rows.plot( figsize=(15,10), title="Dayly Returns")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2177e3ec1c8>




![png](output_27_1.png)



```python
# Calculate cumulative returns
cumulative_returns = (1+ daylyret_all_rows).cumprod()
cumulative_returns.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
      <th>Algo 1</th>
      <th>Algo 2</th>
      <th>S&amp;P 500</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-03-03</th>
      <td>0.998734</td>
      <td>0.995019</td>
      <td>0.999504</td>
      <td>0.993431</td>
      <td>0.998058</td>
      <td>0.999051</td>
      <td>0.995461</td>
    </tr>
    <tr>
      <th>2015-03-04</th>
      <td>1.000962</td>
      <td>0.998245</td>
      <td>0.996972</td>
      <td>0.997617</td>
      <td>0.989486</td>
      <td>1.001464</td>
      <td>0.991093</td>
    </tr>
    <tr>
      <th>2015-03-05</th>
      <td>1.004981</td>
      <td>1.002314</td>
      <td>0.999319</td>
      <td>1.004327</td>
      <td>0.988541</td>
      <td>1.005794</td>
      <td>0.992278</td>
    </tr>
    <tr>
      <th>2015-03-06</th>
      <td>0.997037</td>
      <td>0.998731</td>
      <td>0.990844</td>
      <td>0.991172</td>
      <td>0.983641</td>
      <td>0.994267</td>
      <td>0.978214</td>
    </tr>
    <tr>
      <th>2015-03-09</th>
      <td>0.997617</td>
      <td>1.002951</td>
      <td>0.996633</td>
      <td>0.989534</td>
      <td>0.978283</td>
      <td>0.995563</td>
      <td>0.982072</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plot cumulative returns
cumulative_returns.plot( figsize=(15,10), title="Cumulative Returns")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2177e2f6cc8>




![png](output_29_1.png)


## Risk

Determine the _risk_ of each portfolio:

1. Create a box plot for each portfolio. 
2. Calculate the standard deviation for all portfolios
4. Determine which portfolios are riskier than the S&P 500
5. Calculate the Annualized Standard Deviation


```python
# Box plot to visually show risk

portfolio_a_std = np.random.normal(scale=0.008,size = 100000)
portfolio_b_std = np.random.normal(scale=0.007, size = 100000)
portfolio_c_std = np.random.normal(scale=0.011, size = 100000)
portfolio_d_std = np.random.normal(scale=0.013, size = 100000)
portfolio_e_std = np.random.normal(scale=0.008, size = 100000)
portfolio_f_std = np.random.normal(scale=0.008, size = 100000)
portfolio_g_std = np.random.normal(scale=0.009, size = 100000)


portfolio_std = pd.DataFrame({
    "SOROS FUND MANAGEMENT LLC" : portfolio_a_std, 
    "PAULSON & CO.INC." : portfolio_b_std, 
    "TIGER GLOBAL MANAGEMENT LLC" : portfolio_c_std,
    "BERKSHIRE HATHAWAY INC" : portfolio_d_std,
    "Algo 1" : portfolio_e_std,
    "Algo 2" : portfolio_f_std,   
    "S&P 500" : portfolio_g_std
    
})


portfolio_std.plot.box(figsize=(20,10),title="Portfolio Risk") 
```




    <matplotlib.axes._subplots.AxesSubplot at 0x21700306d48>




![png](output_31_1.png)



```python
# Daily Standard Deviations
# Calculate the standard deviation for each portfolio. 
# Which portfolios are riskier than the S&P 500?
daily_std = daylyret_all_rows.std()
daily_std.head(7)
```




    SOROS FUND MANAGEMENT LLC      0.007895
    PAULSON & CO.INC.              0.007023
    TIGER GLOBAL MANAGEMENT LLC    0.010894
    BERKSHIRE HATHAWAY INC         0.012919
    Algo 1                         0.007620
    Algo 2                         0.008342
    S&P 500                        0.008554
    dtype: float64




```python
# Determine which portfolios are riskier than the S&P 500
#
```


```python
# Calculate the annualized standard deviation (252 trading days)
annu_stand_dev = daily_std * np.sqrt(252)
annu_stand_dev.head()
```




    SOROS FUND MANAGEMENT LLC      0.125335
    PAULSON & CO.INC.              0.111488
    TIGER GLOBAL MANAGEMENT LLC    0.172936
    BERKSHIRE HATHAWAY INC         0.205077
    Algo 1                         0.120967
    dtype: float64



---

## Rolling Statistics

Risk changes over time. Analyze the rolling statistics for Risk and Beta. 

1. Plot the rolling standard deviation of the various portfolios along with the rolling standard deviation of the S&P 500 (consider a 21 day window). Does the risk increase for each of the portfolios at the same time risk increases in the S&P?
2. Construct a correlation table for the algorithmic, whale, and S&P 500 returns. Which returns most closely mimic the S&P?
3. Choose one portfolio and plot a rolling beta between that portfolio's returns and S&P 500 returns. Does the portfolio seem sensitive to movements in the S&P 500?
4. An alternative way to calculate a rolling window is to take the exponentially weighted moving average. This is like a moving window average, but it assigns greater importance to more recent observations. Try calculating the ewm with a 21 day half-life.


```python
# Calculate and plot the rolling standard deviation for
# the S&P 500 and whale portfolios using a 21 trading day window
rollingsd =daylyret_all_rows.rolling(window=21).std()
    
rollingsd.plot(figsize=(20,10),title="21 Day Rolling Standard Deviation") 


```




    <matplotlib.axes._subplots.AxesSubplot at 0x21701e1c648>




![png](output_37_1.png)



```python
# Construct a correlation table
#correlation between return
correlation = daylyret_all_rows.corr()
correlation.head(7)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
      <th>Algo 1</th>
      <th>Algo 2</th>
      <th>S&amp;P 500</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <td>1.000000</td>
      <td>0.699914</td>
      <td>0.561243</td>
      <td>0.754360</td>
      <td>0.321211</td>
      <td>0.826873</td>
      <td>0.837864</td>
    </tr>
    <tr>
      <th>PAULSON &amp; CO.INC.</th>
      <td>0.699914</td>
      <td>1.000000</td>
      <td>0.434479</td>
      <td>0.545623</td>
      <td>0.268840</td>
      <td>0.678152</td>
      <td>0.669732</td>
    </tr>
    <tr>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <td>0.561243</td>
      <td>0.434479</td>
      <td>1.000000</td>
      <td>0.424423</td>
      <td>0.164387</td>
      <td>0.507414</td>
      <td>0.623946</td>
    </tr>
    <tr>
      <th>BERKSHIRE HATHAWAY INC</th>
      <td>0.754360</td>
      <td>0.545623</td>
      <td>0.424423</td>
      <td>1.000000</td>
      <td>0.292033</td>
      <td>0.688082</td>
      <td>0.751371</td>
    </tr>
    <tr>
      <th>Algo 1</th>
      <td>0.321211</td>
      <td>0.268840</td>
      <td>0.164387</td>
      <td>0.292033</td>
      <td>1.000000</td>
      <td>0.288243</td>
      <td>0.279494</td>
    </tr>
    <tr>
      <th>Algo 2</th>
      <td>0.826873</td>
      <td>0.678152</td>
      <td>0.507414</td>
      <td>0.688082</td>
      <td>0.288243</td>
      <td>1.000000</td>
      <td>0.858764</td>
    </tr>
    <tr>
      <th>S&amp;P 500</th>
      <td>0.837864</td>
      <td>0.669732</td>
      <td>0.623946</td>
      <td>0.751371</td>
      <td>0.279494</td>
      <td>0.858764</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
# Calculate variance of all daily returns of AMD vs. S&P 500
variance = daylyret_all_rows['S&P 500'].var()
variance
```




    7.316632424648712e-05




```python
# Calculate beta of all daily returns of AMD
amd_beta = covariance / variance
amd_beta
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-32-7eb80e7ffca4> in <module>
          1 # Calculate beta of all daily returns of AMD
    ----> 2 amd_beta = covariance / variance
          3 amd_beta
    

    NameError: name 'covariance' is not defined



```python
#To calculate variance
#variance = daylyret_all_rows["S&P 500"].var()
```


```python
#Covariance = dayly_return[].cov(dayly_return[])

#Beta= covariance/variance 

#combined_daily_returns = combined_df.pct_change()
#combined_daily_returns.head()

#covariance = combined_daily_returns['AMD'].cov(combined_daily_returns['SP500'])
#covariance
#variance = combined_daily_returns['SP500'].var()
#variance
#amd_beta = covariance / variance
#amd_beta
```


```python
# Calculate a rolling window using the exponentially weighted moving average. 
# rolling_coveriance = dayly_return[].rolling(window 30).cov(dayly_return["SAP 500"])
#rolling_coveriance.plot(),title= ""
```

---

## Sharpe Ratios
In reality, investment managers and thier institutional investors look at the ratio of return-to-risk, and not just returns alone. (After all, if you could invest in one of two portfolios, each offered the same 10% return, yet one offered lower risk, you'd take that one, right?)

1. Using the daily returns, calculate and visualize the Sharpe ratios using a bar plot.
2. Determine whether the algorithmic strategies outperform both the market (S&P 500) and the whales portfolios.


```python
# Calculate annualized Sharpe Ratios
# share ratios calculation 
sharpe_ratios = (daylyret_all_rows.mean()*252)/ (daylyret_all_rows.std()*np.sqrt(252))
sharpe_ratios.head(7)
```




    SOROS FUND MANAGEMENT LLC      0.356417
    PAULSON & CO.INC.             -0.483570
    TIGER GLOBAL MANAGEMENT LLC   -0.121060
    BERKSHIRE HATHAWAY INC         0.621810
    Algo 1                         1.378648
    Algo 2                         0.501364
    S&P 500                        0.648267
    dtype: float64




```python
# Visualize the sharpe ratios as a bar plot
sharpe_ratios.plot(kind= "bar", title = "Sharpe Ratios")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1b7e999ae88>




![png](output_48_1.png)


On the basis of this performance metric, do our algo strategies outperform both 'the market' and the whales? Type your answer here:

---

# Portfolio Returns

In this section, you will build your own portfolio of stocks, calculate the returns, and compare the results to the Whale Portfolios and the S&P 500. 

1. Visit [Google Sheets](https://docs.google.com/spreadsheets/) and use the in-built Google Finance function to choose 3-5 stocks for your own portfolio.
2. Download the data as CSV files and calculate the portfolio returns.
3. Calculate the returns for each stock.
4. Using those returns, calculate the weighted returns for your entire portfolio assuming an equal number of shares for each stock.
5. Add your portfolio returns to the DataFrame with the other portfolios and rerun the analysis. How does your portfolio fair?


## Your analysis should include the following:

- Using all portfolios:
 - The annualized standard deviation (252 trading days) for all portfolios.
 - The plotted rolling standard deviation using a 21 trading day window for all portfolios.
 - The calculated annualized Sharpe Ratios and the accompanying bar plot visualization.
 - A correlation table.
- Using your custom portfolio and one other of your choosing:
 - The plotted beta. 

## Choose 3-5 custom stocks with at last 1 year's worth of historic prices and create a DataFrame of the closing prices and dates for each stock.


```python
# Read the first stock
dji_historical_path = Path("Resources/dji_historical.csv")
dji_historical= pd.read_csv(dji_historical_path,index_col= "Trade DATE",parse_dates = True, infer_datetime_format=True)
dji_historical.sort_index
dji_historical.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>Close</th>
      <th>Open</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-08</th>
      <td>DJI</td>
      <td>26014.0</td>
      <td>25947.0</td>
    </tr>
    <tr>
      <th>2019-05-07</th>
      <td>DJI</td>
      <td>25973.0</td>
      <td>26220.0</td>
    </tr>
    <tr>
      <th>2019-05-06</th>
      <td>DJI</td>
      <td>26405.0</td>
      <td>26284.0</td>
    </tr>
    <tr>
      <th>2019-05-05</th>
      <td>DJI</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2019-05-03</th>
      <td>DJI</td>
      <td>26499.0</td>
      <td>26273.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Delete colums
dji_historical = dji_historical.drop(columns=["Open"])
dji_historical.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-08</th>
      <td>DJI</td>
      <td>26014.0</td>
    </tr>
    <tr>
      <th>2019-05-07</th>
      <td>DJI</td>
      <td>25973.0</td>
    </tr>
    <tr>
      <th>2019-05-06</th>
      <td>DJI</td>
      <td>26405.0</td>
    </tr>
    <tr>
      <th>2019-05-05</th>
      <td>DJI</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2019-05-03</th>
      <td>DJI</td>
      <td>26499.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Rename columns
dji_historical = dji_historical.rename(columns={
    "Close":"NOCP"
})
dji_historical.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>NOCP</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-08</th>
      <td>DJI</td>
      <td>26014.0</td>
    </tr>
    <tr>
      <th>2019-05-07</th>
      <td>DJI</td>
      <td>25973.0</td>
    </tr>
    <tr>
      <th>2019-05-06</th>
      <td>DJI</td>
      <td>26405.0</td>
    </tr>
    <tr>
      <th>2019-05-05</th>
      <td>DJI</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2019-05-03</th>
      <td>DJI</td>
      <td>26499.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Read the first stock
dax_historical_path = Path("Resources/dax_historical.csv")
dax_historical = pd.read_csv(dax_historical_path,index_col= "Trade DATE",parse_dates = True, infer_datetime_format=True)
dax_historical.sort_index()
dax_historical.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>Open</th>
      <th>Close</th>
      <th>High</th>
      <th>Volume</th>
      <th>Low</th>
      <th>Adj Close</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-03</th>
      <td>DAX</td>
      <td>12345.32031</td>
      <td>12412.75000</td>
      <td>12435.66992</td>
      <td>0.0</td>
      <td>12344.23047</td>
      <td>12412.75000</td>
    </tr>
    <tr>
      <th>2019-05-02</th>
      <td>DAX</td>
      <td>12349.09961</td>
      <td>12345.41992</td>
      <td>12402.87012</td>
      <td>0.0</td>
      <td>12303.95996</td>
      <td>12345.41992</td>
    </tr>
    <tr>
      <th>2019-04-30</th>
      <td>DAX</td>
      <td>12313.96973</td>
      <td>12344.08008</td>
      <td>12345.30957</td>
      <td>0.0</td>
      <td>12281.71973</td>
      <td>12344.08008</td>
    </tr>
    <tr>
      <th>2019-04-29</th>
      <td>DAX</td>
      <td>12308.98047</td>
      <td>12328.01953</td>
      <td>12376.05957</td>
      <td>0.0</td>
      <td>12266.33984</td>
      <td>12328.01953</td>
    </tr>
    <tr>
      <th>2019-04-26</th>
      <td>DAX</td>
      <td>12284.45996</td>
      <td>12315.17969</td>
      <td>12323.63965</td>
      <td>0.0</td>
      <td>12259.75977</td>
      <td>12315.17969</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Delete colums
dax_historical = dax_historical.drop(columns=["Open","High","Low","Adj Close","Volume"])
dax_historical.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-03</th>
      <td>DAX</td>
      <td>12412.75000</td>
    </tr>
    <tr>
      <th>2019-05-02</th>
      <td>DAX</td>
      <td>12345.41992</td>
    </tr>
    <tr>
      <th>2019-04-30</th>
      <td>DAX</td>
      <td>12344.08008</td>
    </tr>
    <tr>
      <th>2019-04-29</th>
      <td>DAX</td>
      <td>12328.01953</td>
    </tr>
    <tr>
      <th>2019-04-26</th>
      <td>DAX</td>
      <td>12315.17969</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Rename columns
dax_historical = dax_historical.rename(columns={
    "Close":"NOCP"
})
dax_historical.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>NOCP</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-03</th>
      <td>DAX</td>
      <td>12412.75000</td>
    </tr>
    <tr>
      <th>2019-05-02</th>
      <td>DAX</td>
      <td>12345.41992</td>
    </tr>
    <tr>
      <th>2019-04-30</th>
      <td>DAX</td>
      <td>12344.08008</td>
    </tr>
    <tr>
      <th>2019-04-29</th>
      <td>DAX</td>
      <td>12328.01953</td>
    </tr>
    <tr>
      <th>2019-04-26</th>
      <td>DAX</td>
      <td>12315.17969</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Read the first stock
goog_historical_path = Path("Resources/goog_historical.csv")
goog_historical = pd.read_csv(goog_historical_path,index_col= "Trade DATE",parse_dates = True, infer_datetime_format=True)
goog_historical.sort_index()
goog_historical.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>NOCP</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-09</th>
      <td>GOOG</td>
      <td>1162.38</td>
    </tr>
    <tr>
      <th>2019-05-08</th>
      <td>GOOG</td>
      <td>1166.27</td>
    </tr>
    <tr>
      <th>2019-05-07</th>
      <td>GOOG</td>
      <td>1174.10</td>
    </tr>
    <tr>
      <th>2019-05-06</th>
      <td>GOOG</td>
      <td>1189.39</td>
    </tr>
    <tr>
      <th>2019-05-03</th>
      <td>GOOG</td>
      <td>1185.40</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Read the second stock
aapl_historical_path = Path("Resources/aapl_historical.csv")
aapl_historical = pd.read_csv(aapl_historical_path,index_col= "Trade DATE",parse_dates = True, infer_datetime_format=True,)
aapl_historical.sort_index()
aapl_historical.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>NOCP</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-09</th>
      <td>AAPL</td>
      <td>200.72</td>
    </tr>
    <tr>
      <th>2019-05-08</th>
      <td>AAPL</td>
      <td>202.90</td>
    </tr>
    <tr>
      <th>2019-05-07</th>
      <td>AAPL</td>
      <td>202.86</td>
    </tr>
    <tr>
      <th>2019-05-06</th>
      <td>AAPL</td>
      <td>208.48</td>
    </tr>
    <tr>
      <th>2019-05-03</th>
      <td>AAPL</td>
      <td>211.75</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Read the third stock
cost_historical_path = Path("Resources/cost_historical.csv")
cost_historical = pd.read_csv(cost_historical_path,index_col= "Trade DATE",parse_dates = True, infer_datetime_format=True)
cost_historical.sort_index()
cost_historical.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>NOCP</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-09</th>
      <td>COST</td>
      <td>243.47</td>
    </tr>
    <tr>
      <th>2019-05-08</th>
      <td>COST</td>
      <td>241.34</td>
    </tr>
    <tr>
      <th>2019-05-07</th>
      <td>COST</td>
      <td>240.18</td>
    </tr>
    <tr>
      <th>2019-05-06</th>
      <td>COST</td>
      <td>244.23</td>
    </tr>
    <tr>
      <th>2019-05-03</th>
      <td>COST</td>
      <td>244.62</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Concatenate all stocks into a single DataFrame
df_rows = pd.concat(
    [dji_historical, dax_historical,goog_historical, aapl_historical, cost_historical], axis="rows", join="inner")
df_rows
df_rows.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>NOCP</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-05-08</th>
      <td>DJI</td>
      <td>26014.0</td>
    </tr>
    <tr>
      <th>2019-05-07</th>
      <td>DJI</td>
      <td>25973.0</td>
    </tr>
    <tr>
      <th>2019-05-06</th>
      <td>DJI</td>
      <td>26405.0</td>
    </tr>
    <tr>
      <th>2019-05-05</th>
      <td>DJI</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2019-05-03</th>
      <td>DJI</td>
      <td>26499.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Reset the index
df_rows = df_rows.reset_index()
df_rows.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Trade DATE</th>
      <th>Symbol</th>
      <th>NOCP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2019-05-08</td>
      <td>DJI</td>
      <td>26014.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2019-05-07</td>
      <td>DJI</td>
      <td>25973.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2019-05-06</td>
      <td>DJI</td>
      <td>26405.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2019-05-05</td>
      <td>DJI</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2019-05-03</td>
      <td>DJI</td>
      <td>26499.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Pivot so that each column of prices represents a unique symbol
df_rows=df_rows.pivot(index="Trade DATE", columns="Symbol")
df_rows.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="5" halign="left">NOCP</th>
    </tr>
    <tr>
      <th>Symbol</th>
      <th>AAPL</th>
      <th>COST</th>
      <th>DAX</th>
      <th>DJI</th>
      <th>GOOG</th>
    </tr>
    <tr>
      <th>Trade DATE</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2018-05-07</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>12948.13965</td>
      <td>24301.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2018-05-08</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>12912.20996</td>
      <td>24307.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2018-05-09</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>12943.05957</td>
      <td>24502.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2018-05-10</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>13022.87012</td>
      <td>24692.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2018-05-11</th>
      <td>188.59</td>
      <td>195.76</td>
      <td>13001.24023</td>
      <td>24823.0</td>
      <td>1098.26</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Rename a column
df_rows  = df_rows.rename(columns={
    "NOCP GOOG":"GOOG"
})
```


```python
#Count null
df_rows.isnull().sum()
```




          Symbol
    NOCP  AAPL      63
          COST      63
          DAX       63
          DJI       63
          GOOG      63
    dtype: int64




```python
# Drop null
df_rows =df_rows.dropna()
df_rows.isnull().sum()
```




          Symbol
    NOCP  AAPL      0
          COST      0
          DAX       0
          DJI       0
          GOOG      0
    dtype: int64



df_rows_daylyreturn = df_rows.pct_change()
df_rows_daylyreturn.head()

## Calculate the weighted returns for the portfolio assuming an equal number of shares for each stock


```python
# Calculate weighted portfolio returns
weights = [1/3, 1/3, 1/3,1/3,1/3]
portfolio_returns = df_rows_daylyreturn.dot(weights)
portfolio_returns.head()
```




    Trade DATE
    2018-05-11         NaN
    2018-05-14         NaN
    2018-05-15   -6.159242
    2018-05-16   -6.009605
    2018-05-17   -0.871381
    dtype: float64



## Join your portfolio returns to the DataFrame that contains all of the portfolio returns


```python
# Add your "Custom" portfolio to the larger dataframe of fund returns
return_combined = pd.concat(
    [portfolio_retruns, daylyret_all_rows], axis="columns", join="inner")
return_combined
return_combined.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
      <th>Algo 1</th>
      <th>Algo 2</th>
      <th>S&amp;P 500</th>
      <th>Custom</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-04-16</th>
      <td>0.002699</td>
      <td>0.000388</td>
      <td>-0.000831</td>
      <td>0.000837</td>
      <td>-0.006945</td>
      <td>0.002899</td>
      <td>0.000509</td>
      <td>0.000340</td>
    </tr>
    <tr>
      <th>2019-04-17</th>
      <td>-0.002897</td>
      <td>-0.006467</td>
      <td>-0.004409</td>
      <td>0.003222</td>
      <td>-0.010301</td>
      <td>-0.005228</td>
      <td>-0.002274</td>
      <td>0.009292</td>
    </tr>
    <tr>
      <th>2019-04-18</th>
      <td>0.001448</td>
      <td>0.001222</td>
      <td>0.000582</td>
      <td>0.001916</td>
      <td>-0.000588</td>
      <td>-0.001229</td>
      <td>0.001579</td>
      <td>0.001545</td>
    </tr>
    <tr>
      <th>2019-04-22</th>
      <td>-0.002586</td>
      <td>-0.007333</td>
      <td>-0.003640</td>
      <td>-0.001088</td>
      <td>0.000677</td>
      <td>-0.001936</td>
      <td>0.001012</td>
      <td>0.001217</td>
    </tr>
    <tr>
      <th>2019-04-23</th>
      <td>0.007167</td>
      <td>0.003485</td>
      <td>0.006472</td>
      <td>0.013278</td>
      <td>0.004969</td>
      <td>0.009622</td>
      <td>0.008841</td>
      <td>0.011959</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Only compare dates where return data exists for all the stocks (drop NaNs)
return_combined =return_combined.dropna()
```

## Re-run the performance and risk analysis with your portfolio to see how it compares to the others


```python
# Risk
daily_stdd = return_combined.std()
daily_stdd.head(7)
```




    SOROS FUND MANAGEMENT LLC      0.146675
    PAULSON & CO.INC.              0.116732
    TIGER GLOBAL MANAGEMENT LLC    0.232531
    BERKSHIRE HATHAWAY INC         0.247155
    Algo 1                         0.133704
    Algo 2                         0.139556
    S&P 500                        0.152054
    Custom                         0.211496
    dtype: float64




```python
# Rolling
return_combined.rolling(window=21).std(.plot(figsize=(20,10),title="21 Day Rolling Standard Deviation") )
```




    <matplotlib.axes._subplots.AxesSubplot at 0x173bf457e80>




![png](output_76_1.png)



```python
# Annualized Sharpe Ratios
sharpe_ratios_a = (return_combined.mean()*252)/ (return_combined.std()*np.sqrt(252))
sharpe_ratios_a.head(7)
```




    SOROS FUND MANAGEMENT LLC      0.430713
    PAULSON & CO.INC.              0.258738
    TIGER GLOBAL MANAGEMENT LLC   -1.034216
    BERKSHIRE HATHAWAY INC         0.159756
    Algo 1                         2.035665
    Algo 2                         0.080607
    S&P 500                        0.584820
    Custom                         0.933123
    dtype: float64




```python
# Visualize the sharpe ratios as a bar plot
sharpe_ratios_a.plot(kind= "bar", title = "Sharpe Ratios")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x173bf7dfa58>




![png](output_78_1.png)



```python
# Create a correlation analysis
correlation = return_combined.corr()
correlation.head(8)
```




<style  type="text/css" >
    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col0 {
            background-color:  #ffff66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col1 {
            background-color:  #acd666;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col2 {
            background-color:  #69b466;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col3 {
            background-color:  #badc66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col4 {
            background-color:  #40a066;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col5 {
            background-color:  #c8e366;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col6 {
            background-color:  #d3e966;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col7 {
            background-color:  #a3d166;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col0 {
            background-color:  #afd766;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col1 {
            background-color:  #ffff66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col2 {
            background-color:  #6bb566;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col3 {
            background-color:  #7bbd66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col4 {
            background-color:  #47a366;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col5 {
            background-color:  #a8d366;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col6 {
            background-color:  #abd566;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col7 {
            background-color:  #84c266;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col0 {
            background-color:  #369a66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col1 {
            background-color:  #319866;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col2 {
            background-color:  #ffff66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col3 {
            background-color:  #008066;
            color:  #f1f1f1;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col4 {
            background-color:  #008066;
            color:  #f1f1f1;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col5 {
            background-color:  #118866;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col6 {
            background-color:  #45a266;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col7 {
            background-color:  #2d9666;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col0 {
            background-color:  #b9dc66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col1 {
            background-color:  #74ba66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col2 {
            background-color:  #3c9e66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col3 {
            background-color:  #ffff66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col4 {
            background-color:  #3d9e66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col5 {
            background-color:  #a8d366;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col6 {
            background-color:  #cae466;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col7 {
            background-color:  #bbdd66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col0 {
            background-color:  #008066;
            color:  #f1f1f1;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col1 {
            background-color:  #008066;
            color:  #f1f1f1;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col2 {
            background-color:  #008066;
            color:  #f1f1f1;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col3 {
            background-color:  #008066;
            color:  #f1f1f1;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col4 {
            background-color:  #ffff66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col5 {
            background-color:  #008066;
            color:  #f1f1f1;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col6 {
            background-color:  #008066;
            color:  #f1f1f1;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col7 {
            background-color:  #008066;
            color:  #f1f1f1;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col0 {
            background-color:  #cae466;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col1 {
            background-color:  #a9d466;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col2 {
            background-color:  #55aa66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col3 {
            background-color:  #add666;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col4 {
            background-color:  #48a366;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col5 {
            background-color:  #ffff66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col6 {
            background-color:  #d3e966;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col7 {
            background-color:  #a5d266;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col0 {
            background-color:  #d0e866;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col1 {
            background-color:  #a2d066;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col2 {
            background-color:  #69b466;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col3 {
            background-color:  #c7e366;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col4 {
            background-color:  #329866;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col5 {
            background-color:  #cde666;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col6 {
            background-color:  #ffff66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col7 {
            background-color:  #d3e966;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col0 {
            background-color:  #98cc66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col1 {
            background-color:  #71b866;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col2 {
            background-color:  #50a866;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col3 {
            background-color:  #b4da66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col4 {
            background-color:  #2a9466;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col5 {
            background-color:  #97cb66;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col6 {
            background-color:  #d1e866;
            color:  #000000;
        }    #T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col7 {
            background-color:  #ffff66;
            color:  #000000;
        }</style><table id="T_85543dfe_953f_11ea_9340_c0b6f9140de7" ><thead>    <tr>        <th class="blank level0" ></th>        <th class="col_heading level0 col0" >SOROS FUND MANAGEMENT LLC</th>        <th class="col_heading level0 col1" >PAULSON & CO.INC. </th>        <th class="col_heading level0 col2" >TIGER GLOBAL MANAGEMENT LLC</th>        <th class="col_heading level0 col3" >BERKSHIRE HATHAWAY INC</th>        <th class="col_heading level0 col4" >Algo 1</th>        <th class="col_heading level0 col5" >Algo 2</th>        <th class="col_heading level0 col6" >S&P 500</th>        <th class="col_heading level0 col7" >Custom</th>    </tr></thead><tbody>
                <tr>
                        <th id="T_85543dfe_953f_11ea_9340_c0b6f9140de7level0_row0" class="row_heading level0 row0" >SOROS FUND MANAGEMENT LLC</th>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col0" class="data row0 col0" >1</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col1" class="data row0 col1" >0.791962</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col2" class="data row0 col2" >0.478627</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col3" class="data row0 col3" >0.816675</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col4" class="data row0 col4" >0.337826</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col5" class="data row0 col5" >0.862846</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col6" class="data row0 col6" >0.876981</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row0_col7" class="data row0 col7" >0.73325</td>
            </tr>
            <tr>
                        <th id="T_85543dfe_953f_11ea_9340_c0b6f9140de7level0_row1" class="row_heading level0 row1" >PAULSON & CO.INC. </th>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col0" class="data row1 col0" >0.791962</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col1" class="data row1 col1" >1</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col2" class="data row1 col2" >0.485375</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col3" class="data row1 col3" >0.650758</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col4" class="data row1 col4" >0.361301</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col5" class="data row1 col5" >0.783656</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col6" class="data row1 col6" >0.76668</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row1_col7" class="data row1 col7" >0.64421</td>
            </tr>
            <tr>
                        <th id="T_85543dfe_953f_11ea_9340_c0b6f9140de7level0_row2" class="row_heading level0 row2" >TIGER GLOBAL MANAGEMENT LLC</th>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col0" class="data row2 col0" >0.478627</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col1" class="data row2 col1" >0.485375</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col2" class="data row2 col2" >1</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col3" class="data row2 col3" >0.325457</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col4" class="data row2 col4" >0.114554</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col5" class="data row2 col5" >0.409496</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col6" class="data row2 col6" >0.48103</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row2_col7" class="data row2 col7" >0.391972</td>
            </tr>
            <tr>
                        <th id="T_85543dfe_953f_11ea_9340_c0b6f9140de7level0_row3" class="row_heading level0 row3" >BERKSHIRE HATHAWAY INC</th>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col0" class="data row3 col0" >0.816675</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col1" class="data row3 col1" >0.650758</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col2" class="data row3 col2" >0.325457</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col3" class="data row3 col3" >1</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col4" class="data row3 col4" >0.327</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col5" class="data row3 col5" >0.782804</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col6" class="data row3 col6" >0.852303</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row3_col7" class="data row3 col7" >0.801158</td>
            </tr>
            <tr>
                        <th id="T_85543dfe_953f_11ea_9340_c0b6f9140de7level0_row4" class="row_heading level0 row4" >Algo 1</th>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col0" class="data row4 col0" >0.337826</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col1" class="data row4 col1" >0.361301</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col2" class="data row4 col2" >0.114554</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col3" class="data row4 col3" >0.327</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col4" class="data row4 col4" >1</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col5" class="data row4 col5" >0.365512</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col6" class="data row4 col6" >0.289358</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row4_col7" class="data row4 col7" >0.261471</td>
            </tr>
            <tr>
                        <th id="T_85543dfe_953f_11ea_9340_c0b6f9140de7level0_row5" class="row_heading level0 row5" >Algo 2</th>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col0" class="data row5 col0" >0.862846</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col1" class="data row5 col1" >0.783656</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col2" class="data row5 col2" >0.409496</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col3" class="data row5 col3" >0.782804</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col4" class="data row5 col4" >0.365512</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col5" class="data row5 col5" >1</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col6" class="data row5 col6" >0.875721</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row5_col7" class="data row5 col7" >0.739936</td>
            </tr>
            <tr>
                        <th id="T_85543dfe_953f_11ea_9340_c0b6f9140de7level0_row6" class="row_heading level0 row6" >S&P 500</th>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col0" class="data row6 col0" >0.876981</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col1" class="data row6 col1" >0.76668</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col2" class="data row6 col2" >0.48103</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col3" class="data row6 col3" >0.852303</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col4" class="data row6 col4" >0.289358</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col5" class="data row6 col5" >0.875721</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col6" class="data row6 col6" >1</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row6_col7" class="data row6 col7" >0.871875</td>
            </tr>
            <tr>
                        <th id="T_85543dfe_953f_11ea_9340_c0b6f9140de7level0_row7" class="row_heading level0 row7" >Custom</th>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col0" class="data row7 col0" >0.73325</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col1" class="data row7 col1" >0.64421</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col2" class="data row7 col2" >0.391972</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col3" class="data row7 col3" >0.801158</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col4" class="data row7 col4" >0.261471</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col5" class="data row7 col5" >0.739936</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col6" class="data row7 col6" >0.871875</td>
                        <td id="T_85543dfe_953f_11ea_9340_c0b6f9140de7row7_col7" class="data row7 col7" >1</td>
            </tr>
    </tbody></table>




```python
# Beta
# YOUR CODE HERE
```




    <matplotlib.axes._subplots.AxesSubplot at 0x173bf76e828>




![png](output_80_1.png)

